# -*- coding: utf-8 -*-
"""
Created on Tue Dec 31 09:49:54 2024

@author: Administrator
"""

import math
import torch

from torch_geometric.nn.conv import MessagePassing
from torch_geometric.utils import add_self_loops, get_laplacian
import torch.nn.functional as F
from utils import cheby
from torch.nn import Parameter
from scipy.io import savemat



from typing import Optional, Tuple
import math
import torch.nn.functional as F
from torch import Tensor
from torch_sparse import SparseTensor, matmul
from scipy.special import legendre

from torch_geometric.nn.conv import MessagePassing
from torch_geometric.nn.conv.gcn_conv import gcn_norm
from torch_geometric.typing import Adj, OptTensor
from torch.nn import Parameter

import numpy as np
import scipy.sparse as sp
import torch
import torch.nn as nn
from scipy.linalg import expm
import scipy.io as sio

from scipy.linalg import eig, eigh
from scipy.sparse.linalg import eigs, eigsh
import random

from scipy.optimize import curve_fit

from scipy.special import gamma, factorial
from torch_geometric.utils import to_scipy_sparse_matrix, get_laplacian, add_self_loops

# -----------------------------------------------------------
#   Delete the above, my code starts from here
#------------------------------------------------------------


# Helper functions
import scipy.sparse as ss
import scipy.sparse.linalg as ssla
import numpy.random as nr
import matplotlib.pyplot as plt

def matrix_normalize(W,mode='s'):
	"""
	Normalize a weighted adjacency matrix.

	Args:
		W: weighted adjacency matrix
		mode: string indicating the style of normalization;
			's': Symmetric scaling by the degree (default)
			'r': Normalize to row-stochastic
			'c': Normalize to col-stochastic

	Output:
		N: a normalized adjacency matrix or stochastic matrix (in sparse form)
	"""

	dc = np.asarray(W.sum(0)).squeeze()
	dr = np.asarray(W.sum(1)).squeeze()
	[i,j,wij] = ss.find(W)

	# Normalize in desired style
	if mode in 'sl':
		wij = wij/np.sqrt(dr[i]*dc[j])
	elif mode == 'r':
		wij = wij/dr[i]
	elif mode == 'c':
		wij = wij/dc[j]
	else:
		raise ValueError('Unknown mode!')

	N = ss.csr_matrix((wij,(i,j)),shape=W.shape)
	return N


def moments_cheb_dos(A,n,nZ=100,N=10,kind=1):
	"""
	Compute a column vector of Chebyshev moments of the form c(k) = tr(T_k(A)) 
	for k = 0 to N-1. This routine does no scaling; the spectrum of A should 
	already lie in [-1,1]. The traces are computed via a stochastic estimator 
	with nZ probe

	Args:
		A: Matrix or function apply matrix (to multiple RHS)
		n: Dimension of the space
		nZ: Number of probe vectors with which we compute moments
		N: Number of moments to compute
		kind: 1 or 2 for first or second kind Chebyshev functions
		 	(default = 1)

	Output:
		c: a column vector of N moment estimates
		cs: standard deviation of the moment estimator 
			(std/sqrt(nZ))
	"""

	# Create a function handle if given a matrix 
	if callable(A):
		Afun = A
	else:
		if isinstance(A,np.ndarray):
			A = ss.csr_matrix(A)
		Afun = lambda x: A*x

	if N < 2:
		N = 2

	# Set up random probe vectors (allowed to be passed in)
	if not isinstance(nZ,int):
		Z = nZ
		nZ = Z.shape[1]
	else:
		Z = np.sign(nr.randn(n,nZ))

	# Estimate moments for each probe vector
	cZ = moments_cheb(Afun,Z,N,kind)
	c = np.mean(cZ,1)
	cs = np.std(cZ,1,ddof=1)/np.sqrt(nZ)

	c = c.reshape([N,-1])
	cs = cs.reshape([N,-1])
	return c,cs



def moments_cheb(A,V,N=10,kind=1):
	"""
	Compute a column vector of Chebyshev moments of the form c(k) = v'*T_k(A)*v 
	for k = 0 to N-1. This routine does no scaling; the spectrum of A should 
	already lie in [-1,1]

	Args:
		A: Matrix or function apply matrix (to multiple RHS)
		V: Starting vectors
		N: Number of moments to compute
		kind: 1 or 2 for first or second kind Chebyshev functions
			(default = 1)

	Output:
		c: a length N vector of moments
	"""

	if N<2:
		N = 2

	if not isinstance(V,np.ndarray):
		V = V.toarray()

	# Create a function handle if given a matrix
	if  callable(A):
		Afun = A
	else:
		if isinstance(A,np.ndarray):
			A = ss.csr_matrix(A)
		Afun = lambda x: A*x

	n,p = V.shape
	c = np.zeros((N,p))

	# Run three-term recurrence to compute moments
	TVp = V
	TVk = kind*Afun(V)
	c[0] = np.sum(V*TVp,0)
	c[1] = np.sum(V*TVk,0)
	for i in range(2,N):
		TV = 2*Afun(TVk) - TVp
		TVp = TVk
		TVk = TV
		c[i] = sum(V*TVk,0)

	return c

def moments_cheb_ldos(A,n,nZ=100,N=10,kind=1):
	"""
	Compute a column vector of Chebyshev moments of the form 
	c(k,j) = [T_k(A)]_jj for k = 0 to N-1. This routine does no scaling; the 
	spectrum of A should already lie in [-1,1]. The diagonal entries are 
	computed by a stochastic estimator

	Args:
		A: Matrix or function apply matrix (to multiple RHS)
		n: Dimension of the space
		nZ: Number of probe vectors with which we compute moments
		N: Number of moments to compute
		kind: 1 or 2 for first or second kind Chebyshev functions
		 	(default = 1)

	Output:
		c: a (N,n) matrix of moments
		cs: standard deviation of the moment estimator 
			(std/sqrt(nZ))
	"""
	
	# Create a function handle if given a matrix
	if callable(A):
		Afun = A
	else:
		if isinstance(A,np.ndarray):
			A = ss.csr_matrix(A)
		Afun = lambda x: A*x

	if N < 2:
		N = 2

	# Set up random probe vectors (allowed to be passed in)
	if not isinstance(nZ,int):
		Z = nZ
		nZ = Z.shape[1]
	else:
		Z = np.sign(nr.randn(n,nZ))

	# Run three-term recurrence to estimate moments.
	# Use the stochastic diagonal estimator of Bekas and Saad
	# http://www-users.cs.umn.edu/~saad/PDF/usmi-2005-082.pdf

	c = np.zeros((N,n))
	cs = np.zeros((N,n))

	TZp = Z
	X = Z*TZp
	c[0] = np.mean(X,1).T
	cs[0] = np.std(X,1,ddof=1).T

	TZk = kind*Afun(Z)
	X = Z*TZk
	c[1] = np.mean(X,1).T
	cs[1] = np.std(X,1,ddof=1).T

	for i in range(2,N):
		TZ = 2*Afun(TZk) - TZp
		TZp = TZk
		TZk = TZ
		X = Z*TZk
		c[i] = np.mean(X,1).T
		cs[i] = np.std(X,1,ddof=1).T

	cs = cs/np.sqrt(nZ)

	c = c.reshape([N,-1])
	cs = cs.reshape([N,-1])
	return c,cs

def plot_cheb_argparse(npts,c,xx0=-1,ab=np.array([1,0])):
	"""
	Handle argument parsing for plotting routines. Should not be called directly
	by users.

	Args:
		npts: Number of points in a default mesh
		c: Vector of moments
		xx0: Input sampling mesh (original coordinates)
		ab: Scaling map parameters

	Output:
		c: Vector of moments
		xx: Input sampling mesh ([-1,1] coordinates)
		xx0: Input sampling mesh (original coordinates)
		ab: Scaling map parameters
	"""

	if isinstance(xx0,int):
		# only c is given
		xx0 = np.linspace(-1+1e-8,1-1e-8,npts)
		xx = xx0
	else:
		if len(xx0)==2:
			# parameters are c, ab
			ab = xx0
			xx = np.linspace(-1+1e-8,1-1e-8,npts)
			xx0 = ab[0]*xx+ab[1]
		else:
			# parameteres are c, xx0
			xx=xx0

	# All parameters specified
	if not (ab==[1,0]).all():
		xx = (xx0-ab[1])/ab[0]

	return c,xx,xx0,ab

def plot_cheb(varargin,pflag=True):
	"""
	Given a set of first-kind Chebyshev moments, compute the associated density.
	Output a plot of the density function by default

	Args:
		c: Vector of Chebyshev moments (on [-1,1])
		xx: Evaluation points (defaults to mesh of 1001 pts)
		ab: Mapping parameters (default to identity)
		pflag: Option to output the plot

	Output:
		yy: Density evaluated at xx mesh
	"""

	# Parse arguments
	c,xx,xx0,ab = plot_cheb_argparse(1001,*varargin)

	# Run the recurrence
	kind = 1
	N = len(c)
	P0 = xx*0+1
	P1 = kind*xx
	yy =c[0]/(3-kind)+c[1]*xx

	for idx in np.arange(2,N):
		Pn = 2*(xx*P1)-P0
		yy += c[idx]*Pn
		P0 = P1
		P1 = Pn

	# Normalization
	if kind == 1:
		yy = (2/np.pi/ab[0])*(yy/(1e-12+np.sqrt(1-xx**2)))
	else:
		yy = (2/np.pi/ab[0])*(yy*np.sqrt(1-xx**2))

	# Plot by default
	if pflag:
		plt.plot(xx0,yy)
		plt.ion()
		plt.show()
		plt.pause(1)
		plt.clf()
		# input('Press [enter] to continue.')

	yy.reshape([1,-1])
	return yy

def plot_cheb_ldos(varargin,pflag=True):
	"""
	Given a set of first-kind Chebyshev moments, compute the associated local 
	density. Output a plot of the local density functions by default.

	Args:
		c: Vector of Chebyshev moments (on [-1,1])
		xx: Evaluation points (defaults to mesh of 1001 pts)
		ab: Mapping parameters (default to identity)
		pflag: Option to output the plot

	Output:
		yy: Density evaluated at xx mesh (size nnodes-by-nmesh)
		index: Index for spectral re-ordering
	"""

	# Parse arguments
	c,xx,xx0,ab = plot_cheb_argparse(51,*varargin)

	# Run the recurrence to compute CDF
	nmoment,nnodes = c.shape
	txx = np.arccos(xx)
	yy = c[0].reshape((nnodes,1))*(txx-np.pi)/2
	for idx in np.arange(1,nmoment):
		yy = yy +c[idx].reshape((nnodes,1))*np.sin(idx*txx)/idx

	# Difference the CDF to compute histogram
	yy *= -2/np.pi
	yy = yy[:,1:]-yy[:,0:-1]

	# Compute the sorted histogram
	(u,s,v) = ssla.svds(yy,1)
	index = np.argsort(np.squeeze(u))

	# Plot by default
	if pflag:
		fig,ax = plt.subplots()
		yr = np.array([1,nnodes])
		xr = np.array([xx0[0]+xx0[1],xx0[-1]+xx0[-2]],dtype='float')/2
		im = ax.imshow(yy[index,:],extent=np.append(xr,yr),aspect=1.5/nnodes)
		fig.colorbar(im)
		plt.ion()
		plt.show()
		plt.pause(1)
		plt.clf()

	index = np.float64(index.reshape([-1,1]))
	return yy,index

def plot_chebhist(varargin,pflag=False):
	"""
	Given a (filtered) set of first-kind Chebyshev moments, compute the integral
	of the density:
		int_0^s (2/pi)*sqrt(1-x^2)*( c(0)/2+sum_{n=1}^{N-1}c_nT_n(x) )
	Output a histogram of cumulative density function by default.

	Args:
		c: Vector of Chebyshev moments (on [-1,1])
		xx: Evaluation points (defaults to mesh of 21 pts)
		ab: Mapping parameters (default to identity)
		pflag: Option to output the plot

	Output:
		yy: Estimated counts on buckets between xx points
	"""

	# Parse arguments
	c,xx,xx0,ab = plot_cheb_argparse(101,*varargin)

	# Compute CDF and bin the difference
	yy = plot_chebint((c,xx0,ab),pflag=False)
	yy = yy[1:]-yy[:-1]
	xm = (xx0[1:]+xx0[:-1])/2
	
	# Plot by default
	if pflag:
		plt.bar(xm,yy,align='center',width=0.1)
		plt.ion()
		plt.show()
		plt.pause(1)
		plt.clf()

	return xm,yy

def plot_chebint(varargin,pflag=True):
	"""
	Given a (filtered) set of first-kind Chebyshev moments, compute the integral
	of the density:
		int_0^s (2/pi)*sqrt(1-x^2)*( c(0)/2+sum_{n=1}^{N-1}c_nT_n(x) )
	Output a plot of cumulative density function by default.

	Args:
		c: Array of Chebyshev moments (on [-1,1])
		xx: Evaluation points (defaults to mesh of 1001 pts)
		ab: Mapping parameters (default to identity)
		pflag: Option to output the plot

	Output:
		yy: Estimated cumulative density up to each xx point
	"""

	# Parse arguments
	c,xx,xx0,ab = plot_cheb_argparse(1001,*varargin)

	N = len(c)
	txx = np.arccos(xx)
	yy = c[0]*(txx-np.pi)/2
	for idx in np.arange(1,N):
		yy += c[idx]*np.sin(idx*txx)/idx

	yy *= -2/np.pi

	# Plot by default
	if pflag:
		plt.plot(xx0,yy)
		plt.ion()
		plt.show()
		plt.pause(1)
		plt.clf()

	return yy

def plot_chebp(varargin,pflag=True):
	"""
	Given a set of first-kind Chebyshev moments, compute the associated 
	polynomial (*NOT* a density). Output a plot of the polynomial by default.

	Args:
		c: Vector of Chebyshev moments (on [-1,1])
		xx: Evaluation points (defaults to mesh of 1001 pts)
		ab: Mapping parameters (default to identity)
		pflag: Option to output the plot

	Output:
		yy: Polynomial evaluated at xx mesh
	"""

	# Parse arguments
	c,xx,xx0,ab = plot_cheb_argparse(1001,*varargin)
    
	# Run the recurrence
	kind = 1
	N = len(c)
	P0 = xx*0+1
	P1 = kind*xx
	yy = c[0]+c[1]*xx
	for idx in np.arange(2,N):
		Pn = 2*(xx*P1)-P0
		yy += c[idx]*Pn
		P0 = P1
		P1 = Pn

	# Plot by default
	if pflag:
		plt.plot(xx0,yy)
		plt.ion()
		plt.show()
		plt.pause(1)
		plt.clf()

	return yy



import scipy.linalg as spl
import scipy.sparse as sps
import scipy.sparse.linalg as spsl
def _hkt(eivals, timescales):
    """
    Computes heat kernel trace from given eigenvalues, timescales, and normalization.

    For precise definition, please refer to "NetLSD: Hearing the Shape of a Graph" by A. Tsitsulin, D. Mottin, P. Karras, A. Bronstein, E. Müller. Published at KDD'18.
    
    Parameters
    ----------
    eivals : numpy.ndarray
        Eigenvalue vector
    timescales : numpy.ndarray
        Vector of discrete timesteps for the kernel computation
    normalization : str or numpy.ndarray
        Either 'empty', 'complete' or None.
        If None or any ther value, return unnormalized heat kernel trace.
        For the details how 'empty' and 'complete' are computed, please refer to the paper.
        If np.ndarray, they are treated as exact normalization constants
    normalized_laplacian: bool
        Defines whether the eigenvalues came from the normalized Laplacian. It only affects 'complete' normalization.

    Returns
    -------
    numpy.ndarray
        Heat kernel trace signature

    """
    nv = eivals.shape[0]
    hkt = np.zeros(timescales.shape)
    for idx, t in enumerate(timescales):
        hkt[idx] = np.sum(np.exp(-t * eivals))

    return hkt / nv


def mat_to_laplacian(mat, normalized):
    """
    Converts a sparse or dence adjacency matrix to Laplacian.
    
    Parameters
    ----------
    mat : obj
        Input adjacency matrix. If it is a Laplacian matrix already, return it.
    normalized : bool
        Whether to use normalized Laplacian.
        Normalized and unnormalized Laplacians capture different properties of graphs, e.g. normalized Laplacian spectrum can determine whether a graph is bipartite, but not the number of its edges. We recommend using normalized Laplacian.

    Returns
    -------
    obj
        Laplacian of the input adjacency matrix

    Examples
    --------
    >>> mat_to_laplacian(numpy.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]]), False)
    [[ 2, -1, -1], [-1,  2, -1], [-1, -1,  2]]

    """
    if sps.issparse(mat):
        if np.all(mat.diagonal()>=0): # Check diagonal
            if np.all((mat-sps.diags(mat.diagonal())).data <= 0): # Check off-diagonal elements
                return mat
    else:
        if np.all(np.diag(mat)>=0): # Check diagonal
            if np.all(mat - np.diag(mat) <= 0): # Check off-diagonal elements
                return mat
    deg = np.squeeze(np.asarray(mat.sum(axis=1)))
    if sps.issparse(mat):
        L = sps.diags(deg) - mat
    else:
        L = np.diag(deg) - mat
    if not normalized:
        return L
    with np.errstate(divide='ignore'):
        sqrt_deg = 1.0 / np.sqrt(deg)
    sqrt_deg[sqrt_deg==np.inf] = 0
    if sps.issparse(mat):
        sqrt_deg_mat = sps.diags(sqrt_deg)
    else:
        sqrt_deg_mat = np.diag(sqrt_deg)
    return sqrt_deg_mat.dot(L).dot(sqrt_deg_mat)


def updown_linear_approx(eigvals_lower, eigvals_upper, nv):
    """
    Approximates Laplacian spectrum using upper and lower parts of the eigenspectrum.
    
    Parameters
    ----------
    eigvals_lower : numpy.ndarray
        Lower part of the spectrum, sorted
    eigvals_upper : numpy.ndarray
        Upper part of the spectrum, sorted
    nv : int
        Total number of nodes (eigenvalues) in the graph.

    Returns
    -------
    numpy.ndarray
        Vector of approximated eigenvalues

    Examples
    --------
    >>> updown_linear_approx([1, 2, 3], [7, 8, 9], 9)
    array([1,  2,  3,  4,  5,  6,  7,  8,  9])

    """
    nal = len(eigvals_lower)
    nau = len(eigvals_upper)
    if nv < nal + nau:
        raise ValueError('Number of supplied eigenvalues ({0} lower and {1} upper) is higher than number of nodes ({2})!'.format(nal, nau, nv))
    ret = np.zeros(nv)
    ret[:nal] = eigvals_lower
    ret[-nau:] = eigvals_upper
    ret[nal-1:-nau+1] = np.linspace(eigvals_lower[-1], eigvals_upper[0], nv-nal-nau+2)
    return ret


def eigenvalues_auto(mat, n_eivals=100):
    """
    Automatically computes the spectrum of a given Laplacian matrix.
    
    Parameters
    ----------
    mat : numpy.ndarray or scipy.sparse
        Laplacian matrix
    n_eivals : string or int or tuple
        Number of eigenvalues to compute / use for approximation.
        If string, we expect either 'full' or 'auto', otherwise error will be raised. 'auto' lets the program decide based on the faithful usage. 'full' computes all eigenvalues.
        If int, compute n_eivals eigenvalues from each side and approximate using linear growth approximation.
        If tuple, we expect two ints, first for lower part of approximation, and second for the upper part.

    Returns
    -------
    np.ndarray
        Vector of approximated eigenvalues

    Examples
    --------
    >>> eigenvalues_auto(numpy.array([[ 2, -1, -1], [-1,  2, -1], [-1, -1,  2]]), 'auto')
    array([0, 3, 3])

    """
    do_full = True
    n_lower = 100
    n_upper = 100
    nv = mat.shape[0]
    if n_eivals == 'auto':
        if mat.shape[0] > 1024:
            do_full = False
    if n_eivals == 'full':
        do_full = True
    if isinstance(n_eivals, int):
        n_lower = n_upper = n_eivals
        do_full = False
    if isinstance(n_eivals, tuple):
        n_lower, n_upper = n_eivals
        do_full = False
    if do_full and sps.issparse(mat):
        mat = mat.todense()
    if sps.issparse(mat):
        if n_lower == n_upper:
            tr_eivals = spsl.eigsh(mat, 2*n_lower, which='BE', return_eigenvectors=False)
            return updown_linear_approx(tr_eivals[:n_upper], tr_eivals[n_upper:], nv)
        else:
            lo_eivals = spsl.eigsh(mat, n_lower, which='SM', return_eigenvectors=False)[::-1]
            up_eivals = spsl.eigsh(mat, n_upper, which='LM', return_eigenvectors=False)
            return updown_linear_approx(lo_eivals, up_eivals, nv)
    else:
        if do_full:
            return spl.eigvalsh(mat)
        else:
            lo_eivals = spl.eigvalsh(mat, eigvals=(0, n_lower-1))
            up_eivals = spl.eigvalsh(mat, eigvals=(nv-n_upper-1, nv-1))
            return updown_linear_approx(lo_eivals, up_eivals, nv)


def eigenvalues_bound(mat, n_eivals=100):
    """
    Automatically computes the spectrum of a given Laplacian matrix.
    
    Parameters
    ----------
    mat : numpy.ndarray or scipy.sparse
        Laplacian matrix
    n_eivals : string or int or tuple
        Number of eigenvalues to compute / use for approximation.
        If string, we expect either 'full' or 'auto', otherwise error will be raised. 'auto' lets the program decide based on the faithful usage. 'full' computes all eigenvalues.
        If int, compute n_eivals eigenvalues from each side and approximate using linear growth approximation.
        If tuple, we expect two ints, first for lower part of approximation, and second for the upper part.

    Returns
    -------
    np.ndarray
        Vector of approximated eigenvalues

    Examples
    --------
    >>> eigenvalues_auto(numpy.array([[ 2, -1, -1], [-1,  2, -1], [-1, -1,  2]]), 'auto')
    array([0, 3, 3])

    """
    do_full = True
    n_lower = 100
    n_upper = 100
    nv = mat.shape[0]
    if n_eivals == 'auto':
        if mat.shape[0] > 1024:
            do_full = False
    if n_eivals == 'full':
        do_full = True
    if isinstance(n_eivals, int):
        n_lower = n_upper = n_eivals
        do_full = False
    if isinstance(n_eivals, tuple):
        n_lower, n_upper = n_eivals
        do_full = False
    if do_full and sps.issparse(mat):
        mat = mat.todense()
    if sps.issparse(mat):
        if n_lower == n_upper:
            tr_eivals = spsl.eigsh(mat, 2*n_lower, which='BE', return_eigenvectors=False)
            return np.concatenate((tr_eivals[:n_upper], tr_eivals[n_upper:]), axis=None) 
        else:
            lo_eivals = spsl.eigsh(mat, n_lower, which='SM', return_eigenvectors=False)[::-1]
            up_eivals = spsl.eigsh(mat, n_upper, which='LM', return_eigenvectors=False)
            return np.concatenate((lo_eivals, up_eivals), axis=None)
    else:
        if do_full:
            return spl.eigvalsh(mat)
        else:
            lo_eivals = spl.eigvalsh(mat, eigvals=(0, n_lower-1))
            up_eivals = spl.eigvalsh(mat, eigvals=(nv-n_upper-1, nv-1))
            return np.concatenate((lo_eivals, up_eivals), axis=None)

def func(x, p1,p2):
  return p1*np.cos(p2*x) + p2*np.sin(p1*x)

import scipy.linalg
from sklearn.neighbors import KernelDensity
from scipy.sparse.linalg import eigsh

    
    

#! /usr/bin/env python
#
def imtqlx ( n, d, e, z ):

#*****************************************************************************80
#
## IMTQLX diagonalizes a symmetric tridiagonal matrix.
#
#  Discussion:
#
#    This routine is a slightly modified version of the EISPACK routine to
#    perform the implicit QL algorithm on a symmetric tridiagonal matrix.
#
#    The authors thank the authors of EISPACK for permission to use this
#    routine.
#
#    It has been modified to produce the product Q' * Z, where Z is an input
#    vector and Q is the orthogonal matrix diagonalizing the input matrix.
#    The changes consist (essentially) of applying the orthogonal 
#    transformations directly to Z as they are generated.
#
#  Licensing:
#
#    This code is distributed under the GNU LGPL license.
#
#  Modified:
#
#    15 June 2015
#
#  Author:
#
#    John Burkardt.
#
#  Reference:
#
#    Sylvan Elhay, Jaroslav Kautsky,
#    Algorithm 655: IQPACK, FORTRAN Subroutines for the Weights of
#    Interpolatory Quadrature,
#    ACM Transactions on Mathematical Software,
#    Volume 13, Number 4, December 1987, pages 399-415.
#
#    Roger Martin, James Wilkinson,
#    The Implicit QL Algorithm,
#    Numerische Mathematik,
#    Volume 12, Number 5, December 1968, pages 377-383.
#
#  Parameters:
#
#    Input, integer N, the order of the matrix.
#
#    Input, real D(N), the diagonal entries of the matrix.
#
#    Input, real E(N), the subdiagonal entries of the
#    matrix, in entries E(1) through E(N-1). 
#
#    Input, real Z(N), a vector to be operated on.
#
#    Output, real LAM(N), the diagonal entries of the diagonalized matrix.
#
#    Output, real QTZ(N), the value of Q' * Z, where Q is the matrix that 
#    diagonalizes the input symmetric tridiagonal matrix.
#
  import numpy as np
  #from r8_epsilon import r8_epsilon
  
  from sys import exit

  lam = np.zeros ( n )
  for i in range ( 0, n ):
    lam[i] = d[i]

  qtz = np.zeros ( n )
  for i in range ( 0, n ):
    qtz[i] = z[i]

  if ( n == 1 ):
    return lam, qtz

  itn = 30

  prec = 2.220446049250313E-016

  e[n-1] = 0.0

  for l in range ( 1, n + 1 ):

    j = 0

    while ( True ):

      for m in range ( l, n + 1 ):

        if ( m == n ):
          break

        if ( abs ( e[m-1] ) <= prec * ( abs ( lam[m-1] ) + abs ( lam[m] ) ) ):
          break

      p = lam[l-1]

      if ( m == l ):
        break

      if ( itn <= j ):
        print ( '' )
        print ( 'IMTQLX - Fatal error!' )
        print ( '  Iteration limit exceeded.' )
        exit ( 'IMTQLX - Fatal error!' )

      j = j + 1
      g = ( lam[l] - p ) / ( 2.0 * e[l-1] )
      r = np.sqrt ( g * g + 1.0 )

      if ( g < 0.0 ):
        t = g - r
      else:
        t = g + r

      g = lam[m-1] - p + e[l-1] / ( g + t )
 
      s = 1.0
      c = 1.0
      p = 0.0
      mml = m - l

      for ii in range ( 1, mml + 1 ):

        i = m - ii
        f = s * e[i-1]
        b = c * e[i-1]

        if ( abs ( g ) <= abs ( f ) ):
          c = g / f
          r = np.sqrt ( c * c + 1.0 )
          e[i] = f * r
          s = 1.0 / r
          c = c * s
        else:
          s = f / g
          r = np.sqrt ( s * s + 1.0 )
          e[i] = g * r
          c = 1.0 / r
          s = s * c

        g = lam[i] - p
        r = ( lam[i-1] - g ) * s + 2.0 * c * b
        p = s * r
        lam[i] = g + p
        g = c * r - b
        f = qtz[i]
        qtz[i]   = s * qtz[i-1] + c * f
        qtz[i-1] = c * qtz[i-1] - s * f

      lam[l-1] = lam[l-1] - p
      e[l-1] = g
      e[m-1] = 0.0

  for ii in range ( 2, n + 1 ):

     i = ii - 1
     k = i
     p = lam[i-1]

     for j in range ( ii, n + 1 ):

       if ( lam[j-1] < p ):
         k = j
         p = lam[j-1]

     if ( k != i ):

       lam[k-1] = lam[i-1]
       lam[i-1] = p

       p        = qtz[i-1]
       qtz[i-1] = qtz[k-1]
       qtz[k-1] = p

  return lam, qtz


#! /usr/bin/env python
#
def p_polynomial_zeros ( nt ):

#*****************************************************************************80
#
## P_POLYNOMIAL_ZEROS: zeros of Legendre function P(n,x).
#
#  Licensing:
#
#    This code is distributed under the GNU LGPL license.
#
#  Modified:
#
#    16 March 2016
#
#  Author:
#
#    John Burkardt
#
#  Parameters:
#
#    Input, integer NT, the order of the rule.
#
#    Output, real T(NT), the zeros.
#


  a = np.zeros ( nt )

  b = np.zeros ( nt )

  for i in range ( 0, nt ):
    ip1 = i + 1
    b[i] = ip1 / np.sqrt ( 4 * ip1 * ip1 - 1 )

  c = np.zeros ( nt )
  c[0] = np.sqrt ( 2.0 )

  t, w = imtqlx ( nt, a, b, c )

  return  t+1# 0.9*t#for [0, 2] interval


def j_polynomial_zeros ( nt, alpha, beta):

#*****************************************************************************80
#
## P_POLYNOMIAL_ZEROS: zeros of Legendre function P(n,x).
#
#  Licensing:
#
#    This code is distributed under the GNU LGPL license.
#
#  Modified:
#
#    19 October 2023
#
#  Author:
#
#    Dr. Mustafa Coşkun
#
#  Parameters:
#
#    Input, integer NT, the order of the rule, upper and lower are bounds.
#
#    Output, real T(NT), the zeros.
#

  ab = alpha + beta
  abi = 2.0 + ab
  # define the zero-th moment
  zemu = (np.power(2.0,(ab + 1.0))*gamma(alpha + 1.0)*gamma(beta + 1.0))/gamma(abi)
  
  
  x = np.zeros(nt)
  bj = np.zeros(nt)
  
  
  x[0] = (beta -alpha)/abi
  bj[0] = np.sqrt(4.0*(1.0 + alpha)*(1.0 + beta)/((abi + 1.0)*abi*abi))
  a2b2 = beta*beta-alpha*alpha

  for i in range ( 2, nt +1 ):
    abi = 2.0*i + ab
    x[i-1] = a2b2 / ((abi -2.0)*abi)
    abi = np.power(abi,2)
    bj[i-1] = np.sqrt((4.0*i*(i+alpha)*(i + beta)* (i + ab))/((abi -1.0)*abi))

 #bjs = np.sqrt(bj)
  c = np.zeros ( nt )
  c[0] = np.sqrt ( zemu )

  t, w = imtqlx ( nt, x, bj, c )

  return t+1 # for 0.9*t#[0, 2] interval

def g_fullRWR(x):
    return (1)/(1 - x) 
    #return x/(1-x) - x**2 


def g_0(x):
    return (0.1)/(1 - x) 
def g_1(x):
    return (1)/(1 - x)
def g_2(x):
    return ((x)/(1 - x))
def g_3(x):
    return (x**2)/(1 - x)   
def g_4(x):
    return (1)/(1 + 25*x**2)

def g_implicit_cora(x):
  p1 = 1.5820425413644672 
  p2 =  0.389804848348408
  return p1*np.cos(p2*x) + p2*np.sin(p1*x)
def g_implicit_citeseer(x):
  p1 = 3.9219500173434954 
  p2 =  -0.17644030889351756
  print("Is implicit citeseer function called")
  return p1*np.cos(p2*x) + p2*np.sin(p1*x) 

def g_par(x):
    return 1/(1 + x)

def g_appRWR(x,Ksteps):
    sum = 0
    for k in range(Ksteps):
        sum = sum + x**k
    return 0.1*sum

def g_heat(x,Ksteps):
    t = 5
    sum = 0
    for k in range(Ksteps):
        sum = sum + (t**k)/np.math.factorial(k)
    return np.math.exp(-sum)
def g_band_rejection(x):
    return (1-np.exp(-10*(x-1)**2))

def g_band_pass(x):
    return np.exp(-10*(x-1)**2)

def g_low_pass(x):
    return np.exp(-10*x**2)
def g_high_pass(x):
    return 1-np.exp(-10*x**2)

def g_mix_high_low(x):
    return (1/(1-x))*(1-np.exp(-5*x**2))

def g_comb(x):
    return np.abs(np.sin(np.pi*x))
    
def filter_jackson(c):
    N = len(c)
    n = np.arange(N)
    tau = np.pi/(N+1)
    g = ((N-n+1)*np.cos(tau*n) + np.sin(tau*n)/np.tan(tau))/(N+1)
    c = np.multiply(g,c)
    return c

# def filter_jackson(c):
# 	"""
# 	Apply the Jackson filter to a sequence of Chebyshev	moments. The moments 
# 	should be arranged column by column.

# 	Args:
# 		c: Unfiltered Chebyshev moments

# 	Output:
# 		cf: Jackson filtered Chebyshev moments
# 	"""

# 	N = len(c)
# 	n = np.arange(N)
# 	tau = np.pi/(N+1)
# 	g = ((N-n+1)*np.cos(tau*n)+np.sin(tau*n)/np.tan(tau))/(N+1)
# 	g.shape = (N,1)
# 	c = g*c 
#     #print(c)
    
# 	return c

def g_Ours(x):
    sum = 1*1 + 1*x + 4*x**2 + 5*x**3
    return sum
def runge(x):
  """In some places the x range is expanded and the formula give as 1/(1+x^2)
  """
  return 1 / (1 +  x ** 2)

def polyfitA(x,y,n):

    m = x.size
    Q = np.ones((m, 1), dtype=object)
    H = np.zeros((n+1, n), dtype=object)
    k = 0
    j = 0
    for k in range(n):
        q = np.multiply(x,Q[:,k])
        #print(q)
        for j in range(k):
            H[j,k] = np.dot(Q[:,j].T,(q/m))
            q = q - np.dot(H[j,k],(Q[:,j]))
        H[k+1,k] = np.linalg.norm(q)/np.sqrt(m)
        Q = np.column_stack((Q, q/H[k+1,k]))
    #print(Q)
    #print(Q.shape)
    d = np.linalg.solve(Q.astype(np.float64), y.astype(np.float64))
    return d, H

def polyvalA(d,H,s):
    inputtype = H.dtype.type
    M = len(s)
    W = np.ones((M,1), dtype=inputtype)
    n = H.shape[1]
    #print("Complete H", H)
    k = 0
    j = 0
    for k in range(n):
        w = np.multiply(s,W[:,k])
        for j in range(k):
            #print( "H[j,k]",H[j,k])
            w = w -np.dot(H[j,k],( W[:,j]))
        W = np.column_stack((W, w/H[k+1,k]))
    y = W @ d
    return y, W


def t_polynomial_zeros(x0, x1, n):
  return (x1 - x0) * (np.cos((2*np.arange(1, n + 1) - 1)/(2*n)*np.pi) + 1) / 2  + x0

def cheby(i,x):
    if i==0:
        return 1
    elif i==1:
        return x
    else:
        T0=1
        T1=x
        for ii in range(2,i+1):
            T2=2*x*T1-T0
            T0,T1=T1,T2
        return T2

def s_polynomial_zeros(n):
    temp = Parameter(torch.Tensor(n+1))
    temp.data.fill_(1.0)
    coe_tmp=F.relu(temp)
    coe=coe_tmp.clone()
    for i in range(n):
        coe[i]=coe_tmp[0]*cheby(i,math.cos((n+0.5)*math.pi/(n+1)))
        for j in range(1,n+1):
            x_j=math.cos((n-j+0.5)*math.pi/(n+1))
            coe[i]=coe[i]+coe_tmp[j]*cheby(i,x_j)
        coe[i]=2*coe[i]/(n+1)
    return coe

def poylfitA_Cheby(x,y,n,a,b):
    omega = (b-a)/2
    rho = -((b+a)/(b-a))
    
    IN = np.identity(n+1)
    X = np.diag(x)
    
    firstElement = (2/omega)*X + 2*rho*IN
    firstRow = np.concatenate((firstElement, -IN), axis=1)
    secondRow = np.concatenate((IN, np.zeros((n+1, n+1), dtype=object)), axis=1)
    Xcurly = np.concatenate((firstRow, secondRow), axis=0)
    
   
    m = x.size
    
    T = np.ones((m, 1), dtype=object)

    #This is just convert (n,) to (n,1) shape
    x = x.reshape(-1,1)
    #y = y.reshape(-1,1)
    Q = np.concatenate((x,T),axis = 0)

  
    H = np.zeros((n+1, n), dtype=object)
    k = 0
    j = 0
    for k in range(n):
        q = np.matmul(Xcurly,Q[:,k])
        #print(q)
        for j in range(k):
            H[j,k] = np.dot(Q[:,j].T,(q/m))
            q = q - np.dot(H[j,k],(Q[:,j]))
        H[k+1,k] = np.linalg.norm(q)/np.sqrt(m)
        Q = np.column_stack((Q, q/H[k+1,k]))
  
    newQ = Q[n+1:2*(n+1),:];

    d = np.linalg.solve(newQ.astype(np.float64), y.astype(np.float64))
    return d, H

def compare_fitA(f, x, Vander, Threeterm,x0, x1):
  y = f(x)
  n = x.size-1

  if(Vander):
      coefficients = Vandermonde(x, y)

  else:
      if(Threeterm):
          coefficients, H = poylfitA_Cheby(x,y,n,x0,x1)    
      else:
          coefficients, H = polyfitA(x, y, n)
  #K = coefficients.shape[0]
  # for k in range(K-1, -1, -1):
  #     print(coefficients[k], k)
  #print(coefficients)
  return coefficients

def m_polynomial_zeros (x0, x1, n):
    return  np.linspace(x0, x1,n)
def compare_fit_panelA(f, sampling, Vandermonde, Threeterm,degree, x0, x1,zoom=False):
   # Male equedistance
   #x = np.linspace(x0, x1,10)
   
   if (sampling == 'Monomial'):
       x = m_polynomial_zeros(x0, x1, degree)
   elif (sampling == 'Chebyshev'):    
       x = t_polynomial_zeros(x0, x1, degree)
   elif (sampling == 'Legendre'):
       x = p_polynomial_zeros(degree)
   elif (sampling == 'Jacobi'):    
       x = j_polynomial_zeros(degree,0,1)
   else:
    print ('Give proper polynomial to interpolate\n')
    print ('Calling Monimal as default\n')
    x = m_polynomial_zeros(x0, x1, degree)
    
   return compare_fitA(f, x, Vandermonde,Threeterm, x0,x1)


def compare_fit_panelAImplicit(y, Vandermonde, Threeterm,degree, x0, x1,zoom=False):
   # # Male equedistance
   # #x = np.linspace(x0, x1,10)
   # if (sampling == 'Monomial'):
   #     x = m_polynomial_zeros(x0, x1, degree)
   # elif (sampling == 'Chebyshev'):    
   #     x = t_polynomial_zeros(x0, x1, degree)
   # elif (sampling == 'Legendre'):
   #     x = p_polynomial_zeros(degree)
   # elif (sampling == 'Jacobi'):    
   #     x = j_polynomial_zeros(degree,0,1)
   # else:
   #  print ('Give proper polynomial to interpolate\n')
   #  print ('Calling Monimal as default\n')
   #  x = m_polynomial_zeros(x0, x1, degree)
   
   x = m_polynomial_zeros(-1, 1, degree)
    
   return compare_fitAImplicit(y,x, Vandermonde,Threeterm, -1,1)

def compare_fitAImplicit(y,x, Vander, Threeterm,x0, x1):
  # y = f(x)
  n = x.size-1

  if(Vander):
      coefficients = Vandermonde(x, y)

  else:
      if(Threeterm):
          coefficients, H = poylfitA_Cheby(x,y,n,x0,x1)    
      else:
          coefficients, H = polyfitA(x, y, n)
  #K = coefficients.shape[0]
  # for k in range(K-1, -1, -1):
  #     print(coefficients[k], k)
  #print(coefficients)
  return coefficients
def Vandermonde(x, y):
  """Return a polynomial fit of order n+1 to n points"""
  #z = np.polyfit(x, y, x.size + 1)
 
  V = np.vander(x) # Vandermonde matrix
  coeffs = np.linalg.solve(V, y) # f_nodes must be a column vector
  return coeffs


def cheby(i,x):
    if i==0:
        return 1
    elif i==1:
        return x
    else:
        T0=1
        T1=x
        for ii in range(2,i+1):
            T2=2*x*T1-T0
            T0,T1=T1,T2
        return T2

def index_to_mask(index, size):
    mask = torch.zeros(size, dtype=torch.bool)
    mask[index] = 1
    return mask

def take_rest(x, y):
    x.sort()
    y.sort()
    res = []
    j, jmax = 0, len(y)
    for i in range(0, len(x)):
        flag = False
        while j < jmax and y[j] <= x[i]:
            if y[j] == x[i]:
                flag = True
            j += 1
        if not flag:
            res.append(x[i])
    return res


def presum_tensor(h, initial_val):
    length = len(h) + 1
    temp = torch.zeros(length)
    temp[0] = initial_val
    for idx in range(1, length):
        temp[idx] = temp[idx-1] + h[idx-1]
    return temp

def preminus_tensor(h, initial_val):
    length = len(h) + 1
    temp = torch.zeros(length)
    temp[0] = initial_val
    for idx in range(1, length):
        temp[idx] = temp[idx-1] - h[idx-1]
    return temp

def reverse_tensor(h):
    temp = torch.zeros_like(h)
    length = len(temp)
    for idx in range(0, length):
        temp[idx] = h[length-1-idx]
    return temp


class GuidedChebnet_prop(MessagePassing):
    def __init__(self, K, firstfilter,secondfilter, **kwargs):
        super(GuidedChebnet_prop, self).__init__(aggr='add', **kwargs)

        self.K = K
        self.initial_val_low = Parameter(torch.tensor(2.0), requires_grad=False)
        self.temp_low = Parameter(torch.Tensor(self.K), requires_grad=True)
        self.temp_high = Parameter(torch.Tensor(self.K), requires_grad=True)
        self.initial_val_high = Parameter(torch.tensor(0.0), requires_grad=False)
        

        self.FirstFilter = firstfilter
        self.SecondFilter = secondfilter
        print('given filters',self.FirstFilter, self.SecondFilter)
        self.Threeterm = True
        self.Vandermonde = False
        self.Init = 'Chebyshev'
        self.firstImplicit = False
        self.secondImplicit = False
        
        
        implicitFilters = ['DOS', 'Linear', 'Eigen']
        # firstIndicator = False
        # secondIndicator = False
        
        # self.RWFilters = False
        
        if any(self.FirstFilter in filename for filename in implicitFilters):
            self.firstImplicit = True
        if any(self.SecondFilter in filename for filename in implicitFilters):
            self.secondImplicit = True
            
        # else:
        #     self.RWFilters = False
            
        # if any(self.SecondFilter in filename for filename in simpleFilters):
        #     self.RWFilters = True
        # else:
        #     self.RWFilters = False
        
        
        # if (self.RWFilters):
        #     self.lower = -0.9
        #     self.upper = 0.9
        # else:
        self.lower = 0.0
        self.upper = 2.0
        self.RWFilters = False
        self.reset_parameters()

    def reset_parameters(self):
        self.temp_low.data = torch.from_numpy(t_polynomial_zeros(self.lower, self.upper, self.K))
        self.temp_high.data = torch.from_numpy(t_polynomial_zeros(self.lower, self.upper, self.K))

    
    def forward(self, x, edge_index, edge_weight=None, highpass=True):
        if highpass:
            # TEMP = F.relu(self.temp_high)
            # coe_tmp = presum_tensor(TEMP, self.initial_val_high)
        
            if(self.firstImplicit):
                # implement implicit filtering here
                
                node_dim = 0
                A = to_scipy_sparse_matrix(edge_index)
                L = matrix_normalize(A)
                
                # edge_index1, norm1 = get_laplacian(data.edge_index, data.edge_attr,normalization='sym', dtype=data.x.dtype, num_nodes=data.x.size(node_dim))

                # edge_index_tilde, norm_tilde = add_self_loops(edge_index1,norm1,fill_value=-1.0,num_nodes=data.x.size(node_dim))
                # L_tilde = to_scipy_sparse_matrix(edge_index_tilde, norm_tilde, data.x.size(node_dim))
                # L_tilde = sparse_mx_to_torch_sparse_tensor(L_tilde)
                # L = L_tilde
                n = A.shape[0]
                #L = sp.eye(n) - L
                c = moments_cheb_dos(L,n, N = 30)[0]
                #print("C values:",c)
                cl = moments_cheb_ldos(L,n, N = 30)[0]
                c = c.reshape(-1)
                #cl = cl.reshape(-1)
                #print("C 2nd values:",c)
                #y = plot_cheb((c,))
                #yl,idx = plot_cheb_ldos((cl,))
                my_list,yh = plot_chebhist((c,))
                #yi = plot_chebint((c,))
                #yp= plot_chebp((c,))
                #print("Y values:",yh)
                newyh = yh/np.sum(yh)
                #print("Y values:",newyh)
                
                
                #print("My list",my_list)
                my_probabilities = newyh
                
                if(self.FirstFilter == 'DOS'):
                    random_elements = random.choices(my_list, weights=my_probabilities, k=100)
                #print("Random Eigenvalues",random_elements)
                
                
                # # xpart = np.linspace(-1, 1, n)
                # #eigenvalues, eigenvectors = eigsh(L, k=2000, which='LM')  # 'LM' for largest magnitude
                # #print("Largest Eigenvalues:", eigenvalues)
                # eigenvalues, eigenvectors = scipy.linalg.eigh(L.toarray())#eigsh(L, k=n, which='LM')
                
                # # Pick 100 element from equspaced
                # idx = np.round(np.linspace(0, len(eigenvalues) - 1, 11)).astype(int)
                
                # random_elements = eigenvalues[idx]
                
                
                
                # choices = []
                # while len(choices) < 11:
                #     selection = random.choice(random_elements)
                #     if selection not in choices:
                #         choices.append(selection)
                # print (choices)
                
                # random_elements = np.sort(choices)
                    random_elements = np.sort(random_elements)
                elif(self.FirstFilter == 'Linear'):
                    random_elements = eigenvalues_auto(L,50)
                    random_elements = np.sort(random_elements)
                    #print("Schur Computed Eigenvalues and its count",random_elements, random_elements.shape[0])
                    idxrandom = np.round(np.linspace(0, len(random_elements) - 1, 101)).astype(int)
                    random_elements = random_elements[idxrandom]
                elif(self.FirstFilter == 'Eigen'):
                    random_elements = eigenvalues_bound(L,50)
                    random_elements = np.sort(random_elements)
                    #print("Schur Computed Eigenvalues and its count",random_elements, random_elements.shape[0])
                    idxrandom = np.round(np.linspace(0, len(random_elements) - 1, 101)).astype(int)
                    random_elements = random_elements[idxrandom]
                
                

                # FOR CORA
                my_theta = [0.6577, 0.7516, 1.0505, 1.1352, 1.2067, 1.244, 1.271, 1.2877, 1.299, 1.3057, 1.6232] # These are for Cora (Make it clever later)
                # p1 =  2.6494165962536744  | p2 =  0.310753585999664 for cora
                # FOR CITESEER
                my_theta = [0.6521, 0.6478, 0.6709, 0.6712, 0.6733, 0.6713, 0.6694, 0.6668, 0.6642, 0.6616, 0.973]
                #p1 =  3.849362587757699  | p2 =  -0.13345821833859586 for citesser
                # FOR PUBMED
                #my_theta = [0.9216, 0.4575, 0.8423, 0.7726, 0.8656, 0.8583, 0.8879, 0.8895, 0.8998, 0.9006, 1.217]
                

                f_lambda = np.zeros(random_elements.shape[0])
                
                xdata = np.linspace(-1, 1,random_elements.shape[0])
                
                for i in range(len(random_elements)):
                    sum = 0
                    for j in range(len(my_theta)):
                        # if(random_elements[i]<0 & j % 2 == 0):
                        # # do noting
                        #     print("Here")
                        # else:    
                        sum = sum + my_theta[j]*random_elements[i]**j
                    f_lambda[i] = sum
                    
               # plt.scatter(xdata, f_lambda)
                
                idx = np.round(np.linspace(0, len(f_lambda) - 1, 11)).astype(int)
                
                pointsOnFunction = f_lambda[idx]
                f_lambda = pointsOnFunction

                
                self.RWFilters = True
                coe_tmp = compare_fit_panelAImplicit(f_lambda, self.Vandermonde, self.Threeterm,self.K+1, -1, 1)
            else:
                
                if(self.FirstFilter == 'g_0'):
                    coe_tmp =  compare_fit_panelA(g_0, self.Init, self.Vandermonde, self.Threeterm,self.K, -0.9, 0.9) 
                    self.RWFilters = True
                elif(self.FirstFilter == 'g_1'):
                    coe_tmp =  compare_fit_panelA(g_1, self.Init, self.Vandermonde, self.Threeterm,self.K, -0.9, 0.9)
                    self.RWFilters = True
                elif(self.FirstFilter == 'g_2'):
                    coe_tmp =  compare_fit_panelA(g_2, self.Init, self.Vandermonde, self.Threeterm,self.K, -0.9, 0.9)
                    self.RWFilters = True
                elif(self.FirstFilter == 'g_3'):
                    coe_tmp =  compare_fit_panelA(g_3, self.Init, self.Vandermonde, self.Threeterm,self.K, -0.9, 0.9)
                    self.RWFilters = True
                elif(self.FirstFilter == 'g_4'):
                    self.RWFilters = True
                    coe_tmp =  compare_fit_panelA(g_4, self.Init, self.Vandermonde, self.Threeterm,self.K, -0.9, 0.9)
                elif(self.FirstFilter == 'g_band_rejection'):
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_band_rejection, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                elif(self.FirstFilter == 'g_band_pass'):
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_band_pass, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                elif(self.FirstFilter == 'g_low_pass'):
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_low_pass, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                elif(self.FirstFilter == 'g_high_pass'):
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_high_pass, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                elif(self.FirstFilter == 'g_comb'):
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_comb, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                else:
                    print('Give a proper filter name I am using high pass here as default')
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_high_pass, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                
        else:
            if(self.secondImplicit):
                # implement implicit filtering here
                
                node_dim = 0
                A = to_scipy_sparse_matrix(edge_index)
                L = matrix_normalize(A)
                
                # edge_index1, norm1 = get_laplacian(data.edge_index, data.edge_attr,normalization='sym', dtype=data.x.dtype, num_nodes=data.x.size(node_dim))

                # edge_index_tilde, norm_tilde = add_self_loops(edge_index1,norm1,fill_value=-1.0,num_nodes=data.x.size(node_dim))
                # L_tilde = to_scipy_sparse_matrix(edge_index_tilde, norm_tilde, data.x.size(node_dim))
                # L_tilde = sparse_mx_to_torch_sparse_tensor(L_tilde)
                # L = L_tilde
                n = A.shape[0]
                #L = sp.eye(n) - L
                c = moments_cheb_dos(L,n, N = 30)[0]
                #print("C values:",c)
                cl = moments_cheb_ldos(L,n, N = 30)[0]
                c = c.reshape(-1)
                #cl = cl.reshape(-1)
                #print("C 2nd values:",c)
                #y = plot_cheb((c,))
                #yl,idx = plot_cheb_ldos((cl,))
                my_list,yh = plot_chebhist((c,))
                #yi = plot_chebint((c,))
                #yp= plot_chebp((c,))
                #print("Y values:",yh)
                newyh = yh/np.sum(yh)
                #print("Y values:",newyh)
                
                
                #print("My list",my_list)
                my_probabilities = newyh
                
                if(self.SecondFilter == 'DOS'):
                    random_elements = random.choices(my_list, weights=my_probabilities, k=100)
                #print("Random Eigenvalues",random_elements)
                
                
                # # xpart = np.linspace(-1, 1, n)
                # #eigenvalues, eigenvectors = eigsh(L, k=2000, which='LM')  # 'LM' for largest magnitude
                # #print("Largest Eigenvalues:", eigenvalues)
                # eigenvalues, eigenvectors = scipy.linalg.eigh(L.toarray())#eigsh(L, k=n, which='LM')
                
                # # Pick 100 element from equspaced
                # idx = np.round(np.linspace(0, len(eigenvalues) - 1, 11)).astype(int)
                
                # random_elements = eigenvalues[idx]
                
                
                
                # choices = []
                # while len(choices) < 11:
                #     selection = random.choice(random_elements)
                #     if selection not in choices:
                #         choices.append(selection)
                # print (choices)
                
                # random_elements = np.sort(choices)
                    random_elements = np.sort(random_elements)
                elif(self.SecondFilter == 'Linear'):
                    random_elements = eigenvalues_auto(L,50)
                    random_elements = np.sort(random_elements)
                    #print("Schur Computed Eigenvalues and its count",random_elements, random_elements.shape[0])
                    idxrandom = np.round(np.linspace(0, len(random_elements) - 1, 101)).astype(int)
                    random_elements = random_elements[idxrandom]
                elif(self.SecondFilter == 'Eigen'):
                    random_elements = eigenvalues_bound(L,50)
                    random_elements = np.sort(random_elements)
                    #print("Schur Computed Eigenvalues and its count",random_elements, random_elements.shape[0])
                    idxrandom = np.round(np.linspace(0, len(random_elements) - 1, 101)).astype(int)
                    random_elements = random_elements[idxrandom]
                
                

                # FOR CORA
                my_theta = [0.6577, 0.7516, 1.0505, 1.1352, 1.2067, 1.244, 1.271, 1.2877, 1.299, 1.3057, 1.6232] # These are for Cora (Make it clever later)
                # p1 =  2.6494165962536744  | p2 =  0.310753585999664 for cora
                # FOR CITESEER
                my_theta = [0.6521, 0.6478, 0.6709, 0.6712, 0.6733, 0.6713, 0.6694, 0.6668, 0.6642, 0.6616, 0.973]
                #p1 =  3.849362587757699  | p2 =  -0.13345821833859586 for citesser
                # FOR PUBMED
                #my_theta = [0.9216, 0.4575, 0.8423, 0.7726, 0.8656, 0.8583, 0.8879, 0.8895, 0.8998, 0.9006, 1.217]
                

                f_lambda = np.zeros(random_elements.shape[0])
                
                xdata = np.linspace(-1, 1,random_elements.shape[0])
                
                for i in range(len(random_elements)):
                    sum = 0
                    for j in range(len(my_theta)):
                        # if(random_elements[i]<0 & j % 2 == 0):
                        # # do noting
                        #     print("Here")
                        # else:    
                        sum = sum + my_theta[j]*random_elements[i]**j
                    f_lambda[i] = sum
                    
                #plt.scatter(xdata, f_lambda)
                
                idx = np.round(np.linspace(0, len(f_lambda) - 1, 11)).astype(int)
                
                pointsOnFunction = f_lambda[idx]
                f_lambda = pointsOnFunction

                
                self.RWFilters = True
                coe_tmp = compare_fit_panelAImplicit(f_lambda, self.Vandermonde, self.Threeterm,self.K+1, -1, 1)
            else:
                
                if(self.SecondFilter == 'g_0'):
                    self.RWFilters = True
                    coe_tmp =  compare_fit_panelA(g_0, self.Init, self.Vandermonde, self.Threeterm,self.K, -0.9, 0.9) # m_polynomial_zeros(-(self.alpha), (self.alpha), self.K)
                elif(self.SecondFilter == 'g_1'):
                    self.RWFilters = True
                    coe_tmp =  compare_fit_panelA(g_1, self.Init, self.Vandermonde, self.Threeterm,self.K,-0.9, 0.9) 
                elif(self.SecondFilter == 'g_2'):
                    self.RWFilters = True
                    coe_tmp =  compare_fit_panelA(g_2, self.Init, self.Vandermonde, self.Threeterm,self.K, -0.9, 0.9)
                elif(self.SecondFilter == 'g_3'):
                    self.RWFilters = True
                    coe_tmp =  compare_fit_panelA(g_3, self.Init, self.Vandermonde, self.Threeterm,self.K, -0.9, 0.9)
                elif(self.SecondFilter == 'g_4'):
                    self.RWFilters = True
                    coe_tmp =  compare_fit_panelA(g_4, self.Init, self.Vandermonde, self.Threeterm,self.K, -0.9, 0.9)
                elif(self.SecondFilter == 'g_band_rejection'):
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_band_rejection, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                elif(self.SecondFilter == 'g_band_pass'):
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_band_pass, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                elif(self.SecondFilter == 'g_low_pass'):
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_low_pass, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                elif(self.SecondFilter == 'g_high_pass'):
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_high_pass, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                elif(self.SecondFilter == 'g_comb'):
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_comb, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                else:
                    print('Give a proper filter name I am using low pass here as the second default')
                    self.RWFilters = False
                    coe_tmp =  compare_fit_panelA(g_high_pass, self.Init, self.Vandermonde, self.Threeterm,self.K, 0.0,2.0)
                # TEMP = F.relu(self.temp_low)
                # coe_tmp = preminus_tensor(TEMP, self.initial_val_low)
                #coe_tmp = compare_fit_panelA(g_band_pass, 'Chebyshev', False, True,self.K+1, 0.0, 2.0)
            
        coeffs = filter_jackson(coe_tmp)
        #print(coeffs)
        coe_tmp = torch.from_numpy(coeffs)
        A = to_scipy_sparse_matrix(edge_index)
        # mdic = {"A": A}
        # savemat("Cora.mat", mdic)
        #coe_tmp = torch.flip(coe_tmp, dims=(0,))
        coe = coe_tmp.clone()

        # for i in range(self.K + 1):
        #     coe[i] = coe_tmp[0] * cheby(i, math.cos((self.K + 0.5) * math.pi / (self.K + 1)))
        #     for j in range(1, self.K + 1):
        #         x_j = math.cos((self.K - j + 0.5) * math.pi / (self.K + 1))
        #         coe[i] = coe[i] + coe_tmp[j] * cheby(i, x_j)
        #     coe[i] = 2 * coe[i] / (self.K + 1)

        # L=I-D^(-0.5)AD^(-0.5)
        edge_index, norm = gcn_norm(edge_index, edge_weight, num_nodes=x.size(0), dtype=x.dtype)
        edge_index1, norm1 = get_laplacian(edge_index, edge_weight, normalization='sym', dtype=x.dtype,
                                           num_nodes=x.size(self.node_dim))

        # L_tilde=L-I
        edge_index_tilde, norm_tilde = add_self_loops(edge_index1, norm1, fill_value=-1.0,
                                                      num_nodes=x.size(self.node_dim))

        
        # homophily = False
        
        # if (homophily):
        #     Tx_1=self.propagate(edge_index,x=x,norm=norm,size=None)
        # else:
        #     Tx_1=self.propagate(edge_index1,x=x,norm=norm1,size=None)
        # out=coe[0]*Tx_0+coe[1]*Tx_1
        # #out = coe[0] / 2 * Tx_0 + coe[1] * Tx_1

        # for i in range(2, self.K-1):
        #     if (homophily):
        #         Tx_2=self.propagate(edge_index,x=Tx_1,norm=norm,size=None)
        #     else:
        #         Tx_2=self.propagate(edge_index1,x=Tx_1,norm=norm1,size=None)
        #     Tx_2 = 2 * Tx_2 - Tx_0
        #     out = out + coe[i] * Tx_2
        #     Tx_0, Tx_1 = Tx_1, Tx_2

        # return out
        Tx_0 = x
        if(self.RWFilters):
           Tx_1 = self.propagate(edge_index_tilde, x=x, norm=norm_tilde, size=None)
        else:
            Tx_1 = self.propagate(edge_index1, x=x, norm=norm1, size=None)

        out=coe[0]*Tx_0+coe[1]*Tx_1

        for i in range(2, self.K-1):
            if(self.RWFilters):
                Tx_2 = self.propagate(edge_index_tilde, x=Tx_1, norm=norm_tilde, size=None)
            else:
                Tx_2 = self.propagate(edge_index1, x=Tx_1, norm=norm1, size=None)
            
            Tx_2 = 2 * Tx_2 - Tx_0
            out = out + coe[i] * Tx_2
            Tx_0, Tx_1 = Tx_1, Tx_2

        return out

    def message(self, x_j, norm):
        return norm.view(-1, 1) * x_j

    def __repr__(self):
        return '{}(K={}, temp={})'.format(self.__class__.__name__, self.K,
                                          self.temp)